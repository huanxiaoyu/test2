def hello name = "Ruby"
  puts "Hello #{name}!"
end

hello "Scala"
hello
