// code-examples/Rounding/generator-script.scala

for (i <- 1 to 10) println(i)