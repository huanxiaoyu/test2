// code-examples/Rounding/no-dot-script.scala

List(1, 2, 3) size