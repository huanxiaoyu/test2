// code-examples/Rounding/one-plus-two-script.scala

1 + 2